package com.map;

import javax.swing.JFrame;

public class Map extends JFrame {
		
	public static void main(String[] args) {
	
	}
}
