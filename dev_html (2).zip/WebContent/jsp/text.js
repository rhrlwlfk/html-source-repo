/**
*
*/
function test() {
	alert("test호출 성공 ");
}