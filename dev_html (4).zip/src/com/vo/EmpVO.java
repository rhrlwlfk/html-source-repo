package com.vo;

public class EmpVO {

}
