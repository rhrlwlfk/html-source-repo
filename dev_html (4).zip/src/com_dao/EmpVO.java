package com_dao;

public class EmpVO {

}
