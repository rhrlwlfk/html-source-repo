package com.dept;

public class DeptListSimulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeptDaoVO ddao = new DeptDaoVO();
		ddao.deptList();
	}

}
